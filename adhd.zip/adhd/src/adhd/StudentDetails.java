/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package adhd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

/**
 *
 * @author Leanne
 */
public class StudentDetails extends javax.swing.JFrame {
    private String name_;
    final String DB_URL = "jdbc:mysql://localhost:3306/adhd"; //connect link
    final String USER = "root";
    final String PASS = "1234";
    Vector assignments = new Vector<String>();
    Vector classes = new Vector<String>();
    boolean orderbydue = false;    
    boolean orderbyalphabet = false;
    boolean highlightoverdue = false;
    
    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    Date currentDate = new Date();
    String date = dateFormat.format(currentDate);   
    
    Connection con;
    ResultSet rs;
    
    String display_assignments_query = "";
    
    String display_assignments_query_done = "";
    
    String display_assignments_query_not_done = "";
    /**
     * Creates new form StudentDetails
     */
    public StudentDetails() {
        initComponents();
    }
    
    public StudentDetails(String name) {
        initComponents();
        setLocationRelativeTo(null);
        setAlwaysOnTop(true);
        this.setTitle("Details for " + name);
        name_ = name;
        createSQLQueries();
        displayAssignments();
        displayClassList();
        displayGuardian();
    }
    
    void createSQLQueries() {
        display_assignments_query = 
            "SELECT assignmentName\n" +
            "FROM student\n" +
            "INNER JOIN assignment ON student.studentID = assignment.studentID\n" +
            "WHERE student.studentName = '" + name_ + "'";
    
        display_assignments_query_done = 
            "SELECT assignmentName\n" +
            "FROM student\n" +
            "INNER JOIN assignment ON student.studentID = assignment.studentID\n" +
            "WHERE student.studentName = '" + name_ + "' AND assignment.status = 'Done'";
    
        display_assignments_query_not_done = 
            "SELECT assignmentName\n" +
            "FROM student\n" +
            "INNER JOIN assignment ON student.studentID = assignment.studentID\n" +
            "WHERE student.studentName = '" + name_ + "' AND assignment.status = 'Not Done'";
    }
    
    void displayGuardian() {
        String aboutText = "";
        String parentName = "";
        String parentNumber = "";
        String schoolName = "";
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            rs = st.executeQuery("SELECT parentName, parentNumber, schoolName\n" +
"FROM parent \nINNER JOIN student ON student.studentID = parent.studentID\nWHERE student.studentID = " + getStudentID(name_));
            while (rs.next()) {
                {
                    parentName += rs.getString("parentName") + ", ";
                    parentNumber += rs.getString("parentNumber") + ", ";
                    schoolName = rs.getString("schoolName");
                }
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
        aboutText += "Parent Name(s): " + parentName.substring(0, parentName.length() - 2);
        aboutText += "\nParent Number(s): " + parentNumber.substring(0, parentNumber.length() - 2);
        aboutText += "\nSchool Name: " + schoolName;
        aboutJTextArea.setText(aboutText);
    }
    
    void displayClassList() {
         try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            rs = st.executeQuery("SELECT className\n" +
"FROM class\n");
            while (rs.next()) {
                {
                    classesJComboBox.addItem(rs.getString("className"));
                }
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
         
         for (int i = 1; i <= 31; i++) {
             dayJComboBox.addItem(Integer.toString(i));
         }
         
         for (int i = 1; i <= 12; i++) {
             monthJComboBox.addItem(Integer.toString(i));
         }
    }
    
    int getStudentID(String name) {
        int studentID = 0;
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            rs = st.executeQuery("SELECT studentID\n" +
"FROM student\n" +
"WHERE studentName = '" + name_ + "'");
            while (rs.next()) {
                {
                    studentID = rs.getInt("studentID");
                    break;
                }
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
        return studentID;
    }
    
//    public void displayClasses() {
//        StringBuilder builder = new StringBuilder();
//        try {
//            //Class.forName("com.mysql.cj.jdbc.Driver");
//            con = DriverManager.getConnection(DB_URL, USER, PASS);
//            java.sql.Statement st = con.createStatement();
//            rs = st.executeQuery("SELECT class.className, subject, teacherName\n" +
//"FROM class\n" +
//"INNER JOIN assignment ON class.className = assignment.className\n" +
//"WHERE assignment.studentID = " + getStudentID(name_));
//            while (rs.next()) {
//                {
//                    builder.append("Class name: ").append(rs.getString("className"));
//                    builder.append("\nSubject: ").append(rs.getString("subject"));
//                    builder.append("\nTeacher Name: ").append(rs.getString("teacherName"));
//                }
//            }
//        } catch (SQLException e) {
//            e.getErrorCode();
//        }
//        
//        classesJTextArea.setText(builder.toString());
//    }
    
    public void displayAssignmentsDone() {
        String sql_query = display_assignments_query_done;
         if (orderbydue == true)
             sql_query += "\nORDER BY due";
         else if (orderbyalphabet == true)
            sql_query += "\nORDER BY assignmentName";
         else if (highlightoverdue)
            sql_query += " AND due < '" + date + "'";
         
        assignments.clear();
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            rs = st.executeQuery(sql_query);
            while (rs.next()) {
                {
                    assignments.add(rs.getString("assignmentName"));
                }
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
        assignmentsJList.setListData(assignments);
        assignmentsJList.setSelectedIndex(0);
    }
    
    public void displayAssignmentsNotDone() {
        String sql_query = display_assignments_query_not_done;
        if (orderbydue == true)
            sql_query += "\nORDER BY due";
        else if (orderbyalphabet == true)
            sql_query += "\nORDER BY assignmentName";
        else if (highlightoverdue)
            sql_query += " AND due < '" + date + "'";
        
        assignments.clear();
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            rs = st.executeQuery(sql_query);
            while (rs.next()) {
                {
                    assignments.add(rs.getString("assignmentName"));
                }
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
        assignmentsJList.setListData(assignments);
        assignmentsJList.setSelectedIndex(0);
    }
    
    public void displayAssignments() {
        String sql_query = display_assignments_query;
        if (orderbydue == true)
            sql_query += "\nORDER BY due";
        else if (orderbyalphabet == true)
            sql_query += "\nORDER BY assignmentName";
        else if (highlightoverdue)
            sql_query += " AND due < '" + date + "'";
        assignments.clear();
        System.out.println("sql query is " + sql_query);
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            rs = st.executeQuery(sql_query);
//            rs = st.executeQuery("SELECT assignmentName\n" +
//            "FROM student\n" +
//            "INNER JOIN assignment ON student.studentID = assignment.studentID\n" +
//            "WHERE student.studentName = '" + name_ + "'");
            while (rs.next()) {
                {
                    assignments.add(rs.getString("assignmentName"));
                }
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
        assignmentsJList.setListData(assignments);
        assignmentsJList.setSelectedIndex(0);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        assignmentsJPanel = new javax.swing.JPanel();
        assignmentsJScrollPane = new javax.swing.JScrollPane();
        assignmentsJList = new javax.swing.JList<>();
        classNameJTextField = new javax.swing.JTextField();
        classNameJLabel = new javax.swing.JLabel();
        subjectJLabel = new javax.swing.JLabel();
        subjectJTextField = new javax.swing.JTextField();
        teacherJLabel = new javax.swing.JLabel();
        teacherJTextField = new javax.swing.JTextField();
        assignmentOptionsJComboBox = new javax.swing.JComboBox<>();
        dueJTextField = new javax.swing.JTextField();
        teacherJLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        addJPanel = new javax.swing.JPanel();
        assignmentNameJTextField = new javax.swing.JTextField();
        classesJComboBox = new javax.swing.JComboBox<>();
        enterAssignmentJButton = new javax.swing.JButton();
        assignmentNameJLabel = new javax.swing.JLabel();
        aClassNameJLabel = new javax.swing.JLabel();
        aStatusJLabel = new javax.swing.JLabel();
        aDueStatusJLabel = new javax.swing.JLabel();
        statusJComboBox = new javax.swing.JComboBox<>();
        yearJComboBox = new javax.swing.JComboBox<>();
        monthJComboBox = new javax.swing.JComboBox<>();
        dayJComboBox = new javax.swing.JComboBox<>();
        aboutJPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        aboutJTextArea = new javax.swing.JTextArea();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        dueJCheckBoxMenuItem = new javax.swing.JCheckBoxMenuItem();
        alphabetJCheckBoxMenuItem = new javax.swing.JCheckBoxMenuItem();
        overdueJCheckBoxMenuItem = new javax.swing.JCheckBoxMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        assignmentsJList.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                assignmentsJListValueChanged(evt);
            }
        });
        assignmentsJScrollPane.setViewportView(assignmentsJList);

        classNameJTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                classNameJTextFieldActionPerformed(evt);
            }
        });

        classNameJLabel.setText("Class Name");
        classNameJLabel.setToolTipText("");

        subjectJLabel.setText("Subject");
        subjectJLabel.setToolTipText("");

        teacherJLabel.setText("Teacher");
        teacherJLabel.setToolTipText("");

        assignmentOptionsJComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Done", "Not Done" }));
        assignmentOptionsJComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                assignmentOptionsJComboBoxItemStateChanged(evt);
            }
        });

        dueJTextField.setEditable(false);
        dueJTextField.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N

        teacherJLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        teacherJLabel1.setText("Due");
        teacherJLabel1.setToolTipText("");

        jButton1.setText("Close");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout assignmentsJPanelLayout = new javax.swing.GroupLayout(assignmentsJPanel);
        assignmentsJPanel.setLayout(assignmentsJPanelLayout);
        assignmentsJPanelLayout.setHorizontalGroup(
            assignmentsJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(assignmentsJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(assignmentsJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(assignmentsJPanelLayout.createSequentialGroup()
                        .addComponent(assignmentsJScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 273, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(assignmentsJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(teacherJLabel1)
                            .addComponent(subjectJLabel)
                            .addComponent(subjectJTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                            .addComponent(classNameJTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                            .addComponent(classNameJLabel)
                            .addComponent(teacherJLabel)
                            .addComponent(teacherJTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 152, Short.MAX_VALUE)
                            .addComponent(dueJTextField))
                        .addGap(20, 20, 20))
                    .addGroup(assignmentsJPanelLayout.createSequentialGroup()
                        .addComponent(assignmentOptionsJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addGap(52, 52, 52))))
        );
        assignmentsJPanelLayout.setVerticalGroup(
            assignmentsJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(assignmentsJPanelLayout.createSequentialGroup()
                .addGroup(assignmentsJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(assignmentsJPanelLayout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addComponent(classNameJLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(classNameJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(subjectJLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(subjectJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(teacherJLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(teacherJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(teacherJLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dueJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(assignmentsJPanelLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(assignmentsJScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(assignmentsJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(assignmentsJPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(assignmentOptionsJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(24, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, assignmentsJPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("Assignments", assignmentsJPanel);

        assignmentNameJTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                assignmentNameJTextFieldActionPerformed(evt);
            }
        });

        enterAssignmentJButton.setText("Enter");
        enterAssignmentJButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enterAssignmentJButtonActionPerformed(evt);
            }
        });

        assignmentNameJLabel.setText("Assignment Name");

        aClassNameJLabel.setText("Class Name");

        aStatusJLabel.setText("Status");

        aDueStatusJLabel.setText("Due");

        statusJComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Not Done", "Done" }));

        yearJComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2023", "2024", "2025", "2026" }));

        javax.swing.GroupLayout addJPanelLayout = new javax.swing.GroupLayout(addJPanel);
        addJPanel.setLayout(addJPanelLayout);
        addJPanelLayout.setHorizontalGroup(
            addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(assignmentNameJLabel)
                    .addComponent(aClassNameJLabel)
                    .addComponent(aStatusJLabel)
                    .addComponent(aDueStatusJLabel))
                .addGap(57, 57, 57)
                .addGroup(addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(assignmentNameJTextField)
                        .addComponent(classesJComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(statusJComboBox, 0, 126, Short.MAX_VALUE))
                    .addComponent(enterAssignmentJButton)
                    .addGroup(addJPanelLayout.createSequentialGroup()
                        .addComponent(yearJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(monthJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(dayJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(51, Short.MAX_VALUE))
        );
        addJPanelLayout.setVerticalGroup(
            addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addJPanelLayout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(assignmentNameJTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(assignmentNameJLabel))
                .addGap(18, 18, 18)
                .addGroup(addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classesJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(aClassNameJLabel))
                .addGap(18, 18, 18)
                .addGroup(addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(aStatusJLabel)
                    .addComponent(statusJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(addJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(aDueStatusJLabel)
                    .addComponent(yearJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(monthJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dayJComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(enterAssignmentJButton)
                .addContainerGap(130, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Add Assignment", addJPanel);

        aboutJTextArea.setEditable(false);
        aboutJTextArea.setColumns(20);
        aboutJTextArea.setRows(5);
        jScrollPane1.setViewportView(aboutJTextArea);

        javax.swing.GroupLayout aboutJPanelLayout = new javax.swing.GroupLayout(aboutJPanel);
        aboutJPanel.setLayout(aboutJPanelLayout);
        aboutJPanelLayout.setHorizontalGroup(
            aboutJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aboutJPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 451, Short.MAX_VALUE)
                .addContainerGap())
        );
        aboutJPanelLayout.setVerticalGroup(
            aboutJPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(aboutJPanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(87, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("About", aboutJPanel);

        jMenu1.setText("File");

        dueJCheckBoxMenuItem.setText("Order by Due Date");
        dueJCheckBoxMenuItem.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                dueJCheckBoxMenuItemStateChanged(evt);
            }
        });
        jMenu1.add(dueJCheckBoxMenuItem);

        alphabetJCheckBoxMenuItem.setText("Order by Alphebet");
        alphabetJCheckBoxMenuItem.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                alphabetJCheckBoxMenuItemStateChanged(evt);
            }
        });
        jMenu1.add(alphabetJCheckBoxMenuItem);

        overdueJCheckBoxMenuItem.setText("Show Overdue");
        overdueJCheckBoxMenuItem.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                overdueJCheckBoxMenuItemStateChanged(evt);
            }
        });
        overdueJCheckBoxMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                overdueJCheckBoxMenuItemActionPerformed(evt);
            }
        });
        jMenu1.add(overdueJCheckBoxMenuItem);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void assignmentsJListValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_assignmentsJListValueChanged
        String assignmentName = assignmentsJList.getSelectedValue();
        try {
            //Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            rs = st.executeQuery("SELECT class.className, class.subject, class.teacherName, assignment.due\n" +
"FROM assignment\n" +
"INNER JOIN class ON assignment.className = class.className\n" +
"WHERE assignment.assignmentName ='" + assignmentName + "'");
            System.out.println("SELECT class.className, class.subject, class.teacherName, assignment.due\n" +
"FROM assignment\n" +
"INNER JOIN class ON assignment.className = class.className\n" +
"WHERE assignment.assignmentName ='" + assignmentName + "'");
            while (rs.next()) {
                {
                    classNameJTextField.setText(rs.getString("className"));
                    subjectJTextField.setText(rs.getString("subject"));
                    teacherJTextField.setText(rs.getString("teacherName"));
                    dueJTextField.setText(rs.getString("due"));
                    break;
                }
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
        
        
        
    }//GEN-LAST:event_assignmentsJListValueChanged

    private void classNameJTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_classNameJTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_classNameJTextFieldActionPerformed

    private void assignmentNameJTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_assignmentNameJTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_assignmentNameJTextFieldActionPerformed

    private void enterAssignmentJButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterAssignmentJButtonActionPerformed
        String assignmentName = assignmentNameJTextField.getText();
        String className = classesJComboBox.getItemAt(classesJComboBox.getSelectedIndex());
        String status = statusJComboBox.getItemAt(statusJComboBox.getSelectedIndex());
        String due = yearJComboBox.getItemAt(yearJComboBox.getSelectedIndex()) + "-"  
                + monthJComboBox.getItemAt(monthJComboBox.getSelectedIndex()) + "-" +
                dayJComboBox.getItemAt(dayJComboBox.getSelectedIndex());
        
        try {
            con = DriverManager.getConnection(DB_URL, USER, PASS);
            java.sql.Statement st = con.createStatement();
            int result = st.executeUpdate("INSERT INTO `assignment` VALUES ('" + assignmentName + "','" 
                    + getStudentID(name_) + "','" + className + "','" + status + "','" + due + "');");
            if (result > 0) {
                System.out.println("worked");
            }
        } catch (SQLException e) {
            e.getErrorCode();
        }
        displayAssignments();
    }//GEN-LAST:event_enterAssignmentJButtonActionPerformed

    private void displayAssignmentDetails() {
        int itemIndex = assignmentOptionsJComboBox.getSelectedIndex();
        if (null == assignmentOptionsJComboBox.getItemAt(itemIndex)) {
            displayAssignments();
        } else switch (assignmentOptionsJComboBox.getItemAt(itemIndex)) {
            case "Done":
                displayAssignmentsDone();
                break;
            case "Not Done":
                displayAssignmentsNotDone();
                break;
            default:
                displayAssignments();
                break;
        }
    }
    private void assignmentOptionsJComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_assignmentOptionsJComboBoxItemStateChanged
        displayAssignmentDetails();
    }//GEN-LAST:event_assignmentOptionsJComboBoxItemStateChanged

    private void dueJCheckBoxMenuItemStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_dueJCheckBoxMenuItemStateChanged
        orderbydue = dueJCheckBoxMenuItem.getState() == true;
        displayAssignmentDetails();
    }//GEN-LAST:event_dueJCheckBoxMenuItemStateChanged

    private void alphabetJCheckBoxMenuItemStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_alphabetJCheckBoxMenuItemStateChanged
        orderbyalphabet = alphabetJCheckBoxMenuItem.getState() == true;
        displayAssignmentDetails();
    }//GEN-LAST:event_alphabetJCheckBoxMenuItemStateChanged

    private void overdueJCheckBoxMenuItemStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_overdueJCheckBoxMenuItemStateChanged
        highlightoverdue = overdueJCheckBoxMenuItem.getState() == true;
        displayAssignmentDetails();    
        System.out.println("Yuh");
        
    }//GEN-LAST:event_overdueJCheckBoxMenuItemStateChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void overdueJCheckBoxMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_overdueJCheckBoxMenuItemActionPerformed
        
//        try {
//            Connection con = DriverManager.getConnection(DB_URL, USER, PASS);
//            java.sql.Statement st = con.createStatement();
//            rs = st.executeQuery("SELECT assignmentName FROM assignment WHERE ");
//            
//            
//       } catch(SQLException e) {
//          e.getErrorCode();
//       }
//        
    }//GEN-LAST:event_overdueJCheckBoxMenuItemActionPerformed

//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(StudentDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(StudentDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(StudentDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(StudentDetails.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new StudentDetails().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel aClassNameJLabel;
    private javax.swing.JLabel aDueStatusJLabel;
    private javax.swing.JLabel aStatusJLabel;
    private javax.swing.JPanel aboutJPanel;
    private javax.swing.JTextArea aboutJTextArea;
    private javax.swing.JPanel addJPanel;
    private javax.swing.JCheckBoxMenuItem alphabetJCheckBoxMenuItem;
    private javax.swing.JLabel assignmentNameJLabel;
    private javax.swing.JTextField assignmentNameJTextField;
    private javax.swing.JComboBox<String> assignmentOptionsJComboBox;
    private javax.swing.JList<String> assignmentsJList;
    private javax.swing.JPanel assignmentsJPanel;
    private javax.swing.JScrollPane assignmentsJScrollPane;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel classNameJLabel;
    private javax.swing.JTextField classNameJTextField;
    private javax.swing.JComboBox<String> classesJComboBox;
    private javax.swing.JComboBox<String> dayJComboBox;
    private javax.swing.JCheckBoxMenuItem dueJCheckBoxMenuItem;
    private javax.swing.JTextField dueJTextField;
    private javax.swing.JButton enterAssignmentJButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JComboBox<String> monthJComboBox;
    private javax.swing.JCheckBoxMenuItem overdueJCheckBoxMenuItem;
    private javax.swing.JComboBox<String> statusJComboBox;
    private javax.swing.JLabel subjectJLabel;
    private javax.swing.JTextField subjectJTextField;
    private javax.swing.JLabel teacherJLabel;
    private javax.swing.JLabel teacherJLabel1;
    private javax.swing.JTextField teacherJTextField;
    private javax.swing.JComboBox<String> yearJComboBox;
    // End of variables declaration//GEN-END:variables
}
